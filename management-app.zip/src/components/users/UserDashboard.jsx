import React from 'react'
import Sidebar from '../Sidebar'

const UserDashboard = () => {
  return (
    <>
    <Sidebar />
    <div className='layout'>
    <div className="header">
          <h2>Dashboard</h2>
        </div>
    </div>
    </>
  )
}

export default UserDashboard